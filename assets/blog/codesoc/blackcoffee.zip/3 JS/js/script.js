function nextImage(){
	var children = $('#images').children();

	children.each(function(index, val){
   		if($(this).css('display') != 'none'){
			$(this).fadeOut(500);
			if(index == children.length - 1){
				children.eq(0).fadeIn(300);
			}else{
				children.eq(index+1).fadeIn(300);
			}
			return false;
		}
	});
    setTimeout(nextImage, 5000);
}
nextImage();



function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function validateForm() {
    var name = document.forms.contact.name.value;
    var email = document.forms.contact.email.value;
    var message = document.forms.contact.message.value;
    if (name === null || name === "") {
        alert("Name must be filled out");
        return false;
    }else if (email === null || email === "") {
        alert("Email must be filled out");
        return false;
    }else if(!validateEmail(email)){
        alert("Please enter a valid email address");
        return false;
	}else if (message === null || message === "") {
        alert("Please enter a message");
        return false;
    }
	
}
