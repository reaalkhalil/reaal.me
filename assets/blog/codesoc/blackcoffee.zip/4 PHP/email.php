<?php
 
if(isset($_POST['email'])) {

    $email_to = "reaal@reaal.me";
    $email_subject = "Message from BlackCoffee";
    $error_message = "";
    if(!isset($_POST['name']) ||
        !isset($_POST['email']) ||
        !isset($_POST['message'])) {
        $error_message = 'We are sorry, but there appears to be a problem with the form you submitted.';       
    }
 
    $name = $_POST['name'];
    $email_from = $_POST['email'];
    $message = $_POST['message'];
 
	if(strlen($message) < 1) {
		$error_message .= 'The message you entered does not appear to be valid.';
	}
 
	if(strlen($error_message) == 0) {

    	function clean_string($string) {
      		$bad = array("content-type","bcc:","to:","cc:","href");
      		return str_replace($bad,"",$string);
    	}
 
    $email_message = "Name: ".clean_string($name)."\n";
    $email_message .= "Email: ".clean_string($email_from)."\n";
    $email_message .= "Message: ".clean_string($message)."\n";
 
	// create email headers
	$headers = 'From: '.$email_from."\r\n".
	'Reply-To: '.$email_from."\r\n" .
	'X-Mailer: PHP/' . phpversion();
 
	mail($email_to, $email_subject, $email_message, $headers);  
 
	$alert_message = "Thank you for contacting us. We will be in touch with you very soon.";

	}else{
  		$alert_message = $error_message;
	}

	// save message in logs
	$file = 'logs/logs.txt';
	$contents = file_get_contents($file);

	$contents .= date('l jS \of F Y h:i:s A').PHP_EOL;
	$contents .= $email_message.PHP_EOL.PHP_EOL;

	file_put_contents($file, $contents);

?>
 
 
 
 
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Black Coffee - no sugar no milk</title>
  <meta name="description" content="Black Coffee House - we only serve black coffee, if you like foam, syrup, sugar, sprinkles, nuts, or anything else in your coffee this is not the place for you! PS: we do serve tea though">
  <meta name="author" content="Reaal">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Abhaya+Libre" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Domine" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
<script src="js/script.js" defer></script>
</head>
<body>
	<img src="img/blackcoffee.png" class="logo">
	<h1>No milk, no sugar... No problem!</h1>
	<ul id="links">
			<li><a href="index.html">Home
			</a></li><li class="current"><a href="contact.html">Contact Us</a></li>
	</ul>

	<div class="content">
		<div class="box">
			<h2> Contact Us</h2>
			<form name="contact" action="email.php" method="post" onsubmit="return validateForm()">
			Name:<br>
			<input name="name"><br>
			Email:<br>
			<input name="email"><br>
			Message:<br>
			<textarea name="message"></textarea><br>
			<input type="submit">
			</form>
		</div>
	</div>
	<div id="footer">
		Copyright &copy; Black Coffee 2016
	</div>

	<script>
  		alert("<?php echo $alert_message; ?>")
		location.replace("contact.html");
	</script>

</body>
</html>
 
<?php } ?>
