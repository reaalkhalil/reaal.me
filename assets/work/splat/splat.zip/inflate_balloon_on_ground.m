%constants
Vtank=0.4;% m^3
Pout = 101000;% Pa
R = 8.314;
T = 288;% K

%initial values
Ptank(1) = 20000000;% Pa
ntank(1) = Ptank(1)*Vtank/R*T;% moles
rballoon(1) = 0.54;
Vballoon(1) = 4*pi*rballoon(1).^3/3;
Pballoon(1) = Pout;
nballoon(1) = Vballoon(1)*Pballoon(1)/(R*T);

tmax=900
timediv=1/100;

for t=1:tmax/timediv;
    dn(t) = 40e-7*timediv*(Ptank(t)-Pballoon(t))^0.5;
    ntank(t+1) = ntank(t) - dn(t);
    nballoon(t+1) = nballoon(t) + dn(t);
    rballoon(t+1)=radius_mooneyrivlin(nballoon(t),Pout,T);
    Ptank(t+1)=ntank(t+1)*R*T/Vtank;
    Vballoon(t+1)=4*pi*rballoon(t+1)^3/3;
    Pballoon(t+1)=nballoon(t+1)*R*T/Vballoon(t+1);
end

figure
plot(timediv*(1:tmax/timediv),rballoon(1:tmax/timediv));