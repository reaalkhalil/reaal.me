clear 
clc
close all

%constants
Vtank=0.05;
m=160;
g=9.8;
R = 8.314;

%initial values
h(1)=35000;
T(1)=atmosphere(h(1),1);
Pout(1)=atmosphere(h(1),2);
rho(1)=atmosphere(h(1),3);

Ptank(1) = 20000000;
ntank(1) = Ptank(1)*Vtank/R*T(1);
rballoon(1) = 0.54;
Vballoon(1) = 4*pi*rballoon(1).^3/3;
Pballoon(1) = Pout(1);
nballoon(1) = Vballoon(1)*Pballoon(1)/(R*T(1));
v(1)=0;
a(1)=-g;

tmax=40000;
timediv=1/50;
aa=0;

for t=1:tmax/timediv;
    %inflate balloon
    if rballoon(t)<3 && Ptank(t)>=Pballoon(t)
        aa=t;
        dnbydt(t) = 40e-7*timediv*(Ptank(t)-Pballoon(t))^0.5;
    else
        dnbydt(t) = 0;
    end
    
    ntank(t+1) = ntank(t) - dnbydt(t);
    nballoon(t+1) = nballoon(t) + dnbydt(t);
    rballoon(t+1)=radius_mooneyrivlin(nballoon(t),Pout(t),T(t));
    Ptank(t+1)=ntank(t+1)*R*T(t)/Vtank;
    Vballoon(t+1)=4*pi*rballoon(t+1)^3/3;
    Pballoon(t+1)=nballoon(t+1)*R*T(t)/Vballoon(t+1);

    Fgrav = m*g;
    Fbuoyancy = rho(t)*Vballoon(t)*g;
    Fdrag = 0.5*rho(t)*v(t)^2*0.5*pi*rballoon(t).^2;
    a(t+1) = (Fbuoyancy+Fdrag-Fgrav)/m;
    v(t+1) = v(t)+a(t)*timediv;
    h(t+1) = h(t)+v(t)*timediv+.5*a(t)*timediv^2;
    
    T(t+1) = atmosphere(h(t+1),1);
    Pout(t+1) = atmosphere(h(t+1),2);
    rho(t+1)= atmosphere(h(t+1),3);
    
    if h(t+1)<=0
        tmax=t;
        break
    end
    
end
aa*timediv

figure
plot(timediv*(1:tmax),h(1:tmax));
