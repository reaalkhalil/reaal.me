function r = radius_mooneyrivlin(nballoon,Pout,T)
    r0=0.54;
    t0=0.0002;
    mu = 300000; % Pa
    R = 8.314; % gas constant
    p0 = 2*mu*t0/r0;
    k = 0.1;
    X = 3*nballoon*R/(4*pi);

    poly = [ (p0*k/r0) Pout (p0*r0) 0 (-X*T) 0 (-p0*k*r0^5) 0 (-p0*r0^7) ];
    r = roots(poly);

    r = r((imag(r) == 0) & (r > 0));
end