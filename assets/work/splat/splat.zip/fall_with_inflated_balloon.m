clear 
clc
close all

%constants
Vtank=0.05;
m=70;
g=9.8;
R = 8.314;

%initial values
h(1)=35000;
T(1)=atmosphere(h(1),1);
Pout(1)=atmosphere(h(1),2);
rho(1)=atmosphere(h(1),3);

Ptank(1) = 20000000;% Pa
ntank(1) = Ptank(1)*Vtank/R*T(1);% moles
rballoon(1) = 3.5;
Vballoon(1) = 4*pi*rballoon(1).^3/3;
Pballoon(1) = Pout(1);
nballoon = Vballoon(1)*Pballoon(1)/(R*T(1));
v(1)=0;
a(1)=-g;

tmax=1500;
timediv=1/50;

for t=1:tmax/timediv;
    rballoon(t+1)=radius_mooneyrivlin(nballoon,Pout(t),T(t));
    Vballoon(t+1)=4*pi*rballoon(t+1)^3/3;
    Pballoon(t+1)=nballoon*R*T(t)/Vballoon(t+1);

    %man falling
    Fgrav = m*g;
    rhoBalloon=Pballoon(t+1)*2/R/T(t)/1000;
    Fbuoyancy = rho(t)*Vballoon(t)*g;
    Fdrag = 0.5*rho(t)*v(t)^2*0.5*pi*rballoon(t).^2;
    a(t+1) = (Fbuoyancy+Fdrag-Fgrav)/m;
    v(t+1) = v(t)+a(t)*timediv;
    h(t+1) = h(t)+v(t)*timediv+.5*a(t)*timediv^2;
    
    T(t+1) = atmosphere(h(t+1),1);
    Pout(t+1) = atmosphere(h(t+1),2);
    rho(t+1)= atmosphere(h(t+1),3);
    
    if h(t+1)<=0
        tmax=t;
        break
    end
end

figure
plot(timediv*(1:tmax),rballoon(1:tmax));
